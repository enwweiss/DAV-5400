Hockey-Scraper
==============

Contents
--------
.. toctree::
   :maxdepth: 1

   nhl_scrape_functions
   nwhl_scrape_functions
   live_scrape
   license_link


.. include:: ../../README.rst
   :start-after: inclusion-marker-for-sphinx

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
