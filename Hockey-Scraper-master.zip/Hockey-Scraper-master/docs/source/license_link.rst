License
=======
.. include:: ../../LICENSE.txt